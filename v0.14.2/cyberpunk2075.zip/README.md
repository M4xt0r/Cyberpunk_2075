# Cyberpunk 2075 — système Foundry VTT

Système de jeu sur mesure pour Cyberpunk 2075 (règles en d20), pour Foundry VTT v13.
Notion reste la source de vérité des règles et du contenu ; ce système en est la version jouable à distance.

## Installation

Dans Foundry : **Systèmes de jeu → Installer un système**, puis coller ce lien de manifeste en bas de la fenêtre :

```
https://github.com/M4xt0r/Cyberpunk_2075/releases/latest/download/system.json
```

Les versions suivantes s'installent avec le bouton **Mettre à jour** du système.

## Avancement

| Étape | Contenu | État |
|---|---|---|
| 1 | Squelette, fiche Personnage page 1 (identité, stats, caractéristiques, compétences, jets) | ✅ v0.1.0 |
| 2 | Armes et objets : items à niveaux, Bloc Effet, attaques, dégâts, critiques, animations | ✅ v0.2.0 |
| 3 | Implants et Humanité : silhouette, améliorations, capsules, activation, compte à rebours, repos long | ✅ v0.3.0 |
| 4 | Classes et progression : talents, carte mère, sous-classes, pack de démarrage, bouton Monter | ✅ v0.4.0 |
| 5 | Hacks : carte, lancement contre la Glace, RAM ou PV (OverClocking), Protocole de violation rapide, emplacements | ✅ v0.5.0 |
| 6 | Ennemis : fiche compacte, bonus saisis, stats forcées, compétences clés, builds A / B, réduction, mort à 0 PV | ✅ v0.6.0 |
| 7 | Véhicules et planques : fiches, améliorations, modules, pilotage, page 3 éditable sur place | ✅ v0.7.0 |
| 8 | Compendiums : armes, objets, implants, hacks, classes et talents, véhicules, planques, ennemis (contenu et images Notion) | ✅ v0.8.0 |
| 9 | Scène : barre d'actions (armes, implants, hacks, talents, jets), couvert et crâne d'Humanité sur les tokens | ✅ v0.9.0 |

## Compendiums

Les sources des compendiums sont dans `packs/_source` ; elles sont générées depuis les données Notion recopiées dans `outils/compendiums` :

```
python3 outils/compendiums/generer.py
```

La publication les compile (`outils/compendiums/compiler.mjs`, avec `@foundryvtt/foundryvtt-cli`) avant de créer l'archive. Les images viennent de Notion (`assets/notion`), converties en WebP.

## Crédits

- Polices Oxanium, Lexend et JetBrains Mono sous licence SIL Open Font License (fichiers `assets/fonts/OFL-*.txt`).
- Inspiré de l'univers de Cyberpunk 2077 et de Mike Pondsmith. Aucun logo ni élément d'interface officiel n'est repris.
