/**
 * Cyberpunk 2075 — système Foundry VTT v13 (d20).
 * Notion est la source de vérité du contenu ; ce système en est la version jouable à distance.
 */
import * as CONFIG_CP from "./config.mjs";
import PersonnageData from "./data/personnage.mjs";
import ArmeData from "./data/arme.mjs";
import ImplantData, { AmeliorationImplantData, CapsuleData } from "./data/implant.mjs";
import { tourDeCombat } from "./documents/humanite.mjs";
import ObjetData from "./data/objet.mjs";
import HackData from "./data/hack.mjs";
import EnnemiData from "./data/ennemi.mjs";
import { VehiculeData, PlanqueData, AmeliorationVehiculeData, ModulePlanqueData } from "./data/vehicule.mjs";
import { FicheVehicule, FichePlanque } from "./sheets/vehicule-sheet.mjs";
import FicheEnnemi from "./sheets/ennemi-sheet.mjs";
import ActeurCP from "./documents/actor.mjs";
import ItemCP from "./documents/item.mjs";
import FichePersonnage from "./sheets/personnage-sheet.mjs";
import { CarteArme, CarteObjet, CarteImplant, CarteSousImplant, CarteTalent, CarteClasse, CarteSousClasse, CarteHack, CarteModule } from "./sheets/carte-item.mjs";
import { TalentData, ClasseData, SousClasseData } from "./data/progression.mjs";
import { signe } from "./dice/jets.mjs";
import { surRenduMessage, surCreationMessage } from "./dice/chat.mjs";
import { jouerAnimation, jouerEffet } from "./animations.mjs";
import BarreActions from "./hud/barre.mjs";
import { ajouterBoutonTour, decompterEffets, majBoutonCombat, zonesAuTourDe } from "./hud/tours.mjs";
import FriseCombat from "./hud/frise.mjs";
import { brancherDeplacements } from "./hud/combat.mjs";
import { dessinerPings, retirerPingsDe } from "./hud/pings.mjs";
import { chargerIndicateurs, dessinerIndicateurs, redessinerActeur } from "./hud/indicateurs.mjs";

const { ID_SYSTEME, CHEMIN } = CONFIG_CP;

Hooks.once("init", () => {
  console.log("Cyberpunk 2075 | Initialisation du système");

  globalThis.cyberpunk2075 = { config: CONFIG_CP, jouerAnimation };
  CONFIG.CP2075 = CONFIG_CP;

  // Documents et modèles de données
  CONFIG.Actor.documentClass = ActeurCP;
  CONFIG.Item.documentClass = ItemCP;
  Object.assign(CONFIG.Actor.dataModels, {
    personnage: PersonnageData,
    ennemi: EnnemiData,
    vehicule: VehiculeData,
    planque: PlanqueData
  });
  Object.assign(CONFIG.Item.dataModels, {
    arme: ArmeData,
    implant: ImplantData,
    ameliorationImplant: AmeliorationImplantData,
    capsule: CapsuleData,
    objet: ObjetData,
    hack: HackData,
    talent: TalentData,
    classe: ClasseData,
    sousClasse: SousClasseData,
    ameliorationVehicule: AmeliorationVehiculeData,
    modulePlanque: ModulePlanqueData
  });

  // Barres de token : Vie, RAM, Humanité
  CONFIG.Actor.trackableAttributes = {
    personnage: { bar: ["vie", "ram", "humanite"], value: [] },
    ennemi: { bar: ["vie", "ram"], value: ["humanite.value"] },
    vehicule: { bar: ["vie"], value: [] }
  };

  // Initiative : 1d20 + bonus (Processeur tactique…)
  CONFIG.Combat.initiative = { formula: "1d20 + @initiative", decimals: 0 };
  // Marqueur du token qui joue : réticule jaune (au lieu du logo Foundry)
  CONFIG.Combat.fallbackTurnMarker = `${CHEMIN}/assets/icones/reticule.svg`;

  // Fiches
  const { DocumentSheetConfig } = foundry.applications.apps;
  DocumentSheetConfig.unregisterSheet(Actor, "core", foundry.appv1.sheets.ActorSheet);
  DocumentSheetConfig.unregisterSheet(Item, "core", foundry.appv1.sheets.ItemSheet);
  DocumentSheetConfig.registerSheet(Actor, ID_SYSTEME, FichePersonnage, {
    types: ["personnage"], makeDefault: true, label: "Fiche Personnage Cyberpunk 2075"
  });
  DocumentSheetConfig.registerSheet(Actor, ID_SYSTEME, FicheVehicule, {
    types: ["vehicule"], makeDefault: true, label: "Fiche Véhicule Cyberpunk 2075"
  });
  DocumentSheetConfig.registerSheet(Actor, ID_SYSTEME, FichePlanque, {
    types: ["planque"], makeDefault: true, label: "Fiche Planque Cyberpunk 2075"
  });
  DocumentSheetConfig.registerSheet(Actor, ID_SYSTEME, FicheEnnemi, {
    types: ["ennemi"], makeDefault: true, label: "Fiche Ennemi Cyberpunk 2075"
  });
  DocumentSheetConfig.registerSheet(Item, ID_SYSTEME, CarteArme, {
    types: ["arme"], makeDefault: true, label: "Carte d'arme Cyberpunk 2075"
  });
  DocumentSheetConfig.registerSheet(Item, ID_SYSTEME, CarteObjet, {
    types: ["objet"], makeDefault: true, label: "Carte d'objet Cyberpunk 2075"
  });
  DocumentSheetConfig.registerSheet(Item, ID_SYSTEME, CarteImplant, {
    types: ["implant"], makeDefault: true, label: "Carte d'implant Cyberpunk 2075"
  });
  DocumentSheetConfig.registerSheet(Item, ID_SYSTEME, CarteSousImplant, {
    types: ["ameliorationImplant", "capsule"], makeDefault: true, label: "Carte d'amélioration Cyberpunk 2075"
  });
  DocumentSheetConfig.registerSheet(Item, ID_SYSTEME, CarteTalent, {
    types: ["talent"], makeDefault: true, label: "Carte de talent Cyberpunk 2075"
  });
  DocumentSheetConfig.registerSheet(Item, ID_SYSTEME, CarteClasse, {
    types: ["classe"], makeDefault: true, label: "Carte de classe Cyberpunk 2075"
  });
  DocumentSheetConfig.registerSheet(Item, ID_SYSTEME, CarteSousClasse, {
    types: ["sousClasse"], makeDefault: true, label: "Carte de sous-classe Cyberpunk 2075"
  });
  DocumentSheetConfig.registerSheet(Item, ID_SYSTEME, CarteHack, {
    types: ["hack"], makeDefault: true, label: "Carte de hack Cyberpunk 2075"
  });
  DocumentSheetConfig.registerSheet(Item, ID_SYSTEME, CarteModule, {
    types: ["ameliorationVehicule", "modulePlanque"], makeDefault: true, label: "Carte d'amélioration / module Cyberpunk 2075"
  });

  // Aides Handlebars
  Handlebars.registerHelper("cpSigne", n => signe(n));

  // Pré-chargement des templates
  foundry.applications.handlebars.loadTemplates([
    `${CHEMIN}/templates/actor/personnage/entete.hbs`,
    `${CHEMIN}/templates/actor/personnage/identite.hbs`,
    `${CHEMIN}/templates/actor/personnage/combat.hbs`,
    `${CHEMIN}/templates/actor/personnage/inventaire.hbs`,
    `${CHEMIN}/templates/actor/personnage/bio.hbs`,
    `${CHEMIN}/templates/actor/personnage/partials/emplacement.hbs`,
    `${CHEMIN}/templates/chat/jet.hbs`,
    `${CHEMIN}/templates/chat/des.hbs`,
    `${CHEMIN}/templates/chat/attaque.hbs`,
    `${CHEMIN}/templates/chat/degats.hbs`,
    `${CHEMIN}/templates/chat/hack.hbs`,
    `${CHEMIN}/templates/actor/ennemi/fiche.hbs`,
    `${CHEMIN}/templates/dialogs/hack.hbs`,
    `${CHEMIN}/templates/chat/utilisation.hbs`,
    `${CHEMIN}/templates/chat/alerte.hbs`,
    `${CHEMIN}/templates/chat/progression.hbs`,
    `${CHEMIN}/templates/dialogs/ameliorations.hbs`,
    `${CHEMIN}/templates/dialogs/jet.hbs`,
    `${CHEMIN}/templates/dialogs/attaque.hbs`,
    `${CHEMIN}/templates/item/partials/haut.hbs`,
    `${CHEMIN}/templates/item/partials/plaques.hbs`,
    `${CHEMIN}/templates/item/partials/bas.hbs`,
    `${CHEMIN}/templates/hud/barre.hbs`,
    `${CHEMIN}/templates/hud/frise.hbs`
  ]);
});

/* -------------------------------------------- */

/** Messages du chat : boutons, parties réservées au MJ ou au propriétaire. */
Hooks.on("renderChatMessageHTML", surRenduMessage);

/** Animations : jouées par chaque client à la création du message. */
Hooks.on("createChatMessage", surCreationMessage);

/**
 * Effets actifs des objets : un tour de moins au début du tour du porteur.
 * Exécuté par un seul MJ pour éviter les doublons.
 */
let dernierTourTraite = null;
Hooks.on("updateCombat", async (combat, changements, options) => {
  if ( !("turn" in changements) && !("round" in changements) ) return;
  if ( game.users.activeGM?.id !== game.user.id ) return;
  // Pas au lancement, ni en revenant à l'acteur précédent, ni deux fois pour le même tour
  if ( options?.cpDemarrage || (options?.direction === -1) ) return;
  const combattant = combat.combatant;
  if ( (combattant?.initiative === null) || (combattant?.initiative === undefined) ) return;
  const cle = `${combat.id}:${combat.round}:${combattant.id}`;
  if ( cle === dernierTourTraite ) return;
  dernierTourTraite = cle;
  const acteur = combattant.actor;
  if ( !acteur ) return;
  if ( acteur.type === "personnage" ) await tourDeCombat(acteur);
  await decompterEffets(acteur);
  await zonesAuTourDe(combattant);
  await retirerPingsDe(combattant);
});

/** Nouveau personnage : le token est lié à la fiche et voit la scène. */
Hooks.on("preCreateActor", (acteur, donnees) => {
  if ( acteur.type !== "personnage" ) return;
  const prototype = {
    actorLink: true,
    disposition: CONST.TOKEN_DISPOSITIONS.FRIENDLY,
    sight: { enabled: true },
    bar1: { attribute: "vie" },
    bar2: { attribute: "ram" }
  };
  acteur.updateSource({ prototypeToken: foundry.utils.mergeObject(prototype, donnees.prototypeToken ?? {}) });
});

/* -------------------------------------------- */
/*  Véhicules et planque liés aux personnages   */
/* -------------------------------------------- */

/** Personnages qui affichent ce véhicule ou cette planque sur leur page 3. */
function personnagesLies(acteur) {
  if ( !acteur || !["vehicule", "planque"].includes(acteur.type) ) return [];
  const uuid = acteur.uuid;
  // Planque : tous les personnages, car elle apparaît selon ses permissions
  if ( acteur.type === "planque" ) return game.actors.filter(a => a.type === "personnage");
  return game.actors.filter(a => (a.type === "personnage") && a.system.vehicules.includes(uuid));
}

/** Recalcule les personnages liés (bonus de planque) et rafraîchit leur fiche. */
function rafraichirLies(acteur) {
  for ( const p of personnagesLies(acteur) ) {
    if ( (acteur.type === "planque") && (p.system.surPlace === acteur.uuid) ) p.reset();
    if ( p.sheet?.rendered ) p.sheet.render(false);
  }
  // Un véhicule dépend de son pilote (compétences des armes de bord)
  if ( acteur?.type === "personnage" ) {
    for ( const v of game.actors.filter(a => (a.type === "vehicule") && (a.system.pilote === acteur.uuid)) ) {
      if ( v.sheet?.rendered ) v.sheet.render(false);
    }
  }
}

Hooks.on("updateActor", acteur => rafraichirLies(acteur));
for ( const crochet of ["createItem", "updateItem", "deleteItem"] ) {
  Hooks.on(crochet, item => { if ( item.parent instanceof Actor ) rafraichirLies(item.parent); });
}

/** Au chargement : les bonus de planque ont besoin que tous les acteurs soient là. */
Hooks.once("ready", () => {
  for ( const p of game.actors.filter(a => (a.type === "personnage") && a.system.surPlace) ) p.reset();
});

/* -------------------------------------------- */
/*  Scène : barre d'actions et indicateurs      */
/* -------------------------------------------- */

let barre = null;
let frise = null;
const rafraichirBarre = acteur => { if ( barre?.concerne(acteur) ) barre.rafraichir(); };

Hooks.once("ready", async () => {
  barre = new BarreActions();
  globalThis.cyberpunk2075.barre = barre;
  barre.render({ force: true });
  ajouterBoutonTour();
  frise = new FriseCombat();
  frise.render({ force: true });
  await chargerIndicateurs();
  if ( canvas?.ready ) canvas.tokens.placeables.forEach(dessinerIndicateurs);
});

// Indicateurs (couvert, crâne d'Humanité) sur les tokens
Hooks.on("drawToken", token => dessinerIndicateurs(token));
Hooks.on("updateToken", doc => { if ( doc.object ) dessinerIndicateurs(doc.object); });
Hooks.on("updateActor", acteur => { redessinerActeur(acteur); rafraichirBarre(acteur); });

// Barre d'actions : suit les changements de l'acteur affiché et de la scène
for ( const crochet of ["createItem", "updateItem", "deleteItem"] ) {
  Hooks.on(crochet, item => { if ( item.parent instanceof Actor ) rafraichirBarre(item.parent); });
}
for ( const crochet of ["canvasReady", "createToken", "deleteToken", "updateToken"] ) Hooks.on(crochet, () => barre?.rafraichir());
Hooks.on("updateUser", (user, changements) => { if ( (user.id === game.user.id) && ("character" in changements) ) barre?.rafraichir(); });
Hooks.on("controlToken", (token, controle) => barre?.suivreToken(token, controle));

// Combat : frise d'ordre de jeu, bouton du MJ, déplacements limités au tour de chacun
brancherDeplacements();
const rafraichirCombat = () => { frise?.rafraichir(); majBoutonCombat(); };
for ( const crochet of ["createCombat", "updateCombat", "deleteCombat", "createCombatant", "updateCombatant", "deleteCombatant", "canvasReady"] ) {
  Hooks.on(crochet, rafraichirCombat);
}
Hooks.on("updateActor", () => frise?.rafraichir());
Hooks.on("updateToken", () => frise?.rafraichir());

// Fin du combat : retire le marqueur de tour resté sur les tokens
Hooks.on("deleteCombat", () => {
  if ( !canvas?.ready ) return;
  for ( const t of canvas.tokens.placeables ) {
    try {
      t.renderFlags?.set({ refreshTurnMarker: true });
      t._refreshTurnMarker?.();
    } catch (err) { console.warn("Cyberpunk 2075 | Marqueur de tour :", err); }
  }
});

// Zone persistante qui disparaît : l'animation de la zone est rejouée à sa place
Hooks.on("deleteTile", tuile => {
  const z = tuile.flags?.cyberpunk2075?.zone;
  if ( !z || (canvas?.scene?.id !== tuile.parent?.id) ) return;
  const src = z.effetFin || tuile.texture?.src;
  jouerEffet(src, { x: tuile.x + tuile.width / 2, y: tuile.y + tuile.height / 2 }, Math.max(tuile.width, tuile.height), { avecSon: false }).catch(() => null);
});

/* -------------------------------------------- */
/*  Coup de poing : arme de base de tout le monde */
/* -------------------------------------------- */

const aCoupDePoing = acteur => acteur.items.some(i => i.flags?.cyberpunk2075?.base === "poing");

async function donnerCoupDePoing(acteur) {
  if ( !["personnage", "ennemi"].includes(acteur?.type) || aCoupDePoing(acteur) ) return;
  await acteur.createEmbeddedDocuments("Item", [CONFIG_CP.donneesCoupDePoing()]);
}

Hooks.on("createActor", (acteur, options, userId) => {
  if ( userId === game.user.id ) donnerCoupDePoing(acteur).catch(err => console.warn("Cyberpunk 2075 | Coup de poing :", err));
});

// Acteurs déjà présents dans le monde : le MJ actif leur donne le coup de poing une fois
Hooks.once("ready", async () => {
  if ( game.users.activeGM?.id !== game.user.id ) return;
  for ( const acteur of game.actors ) {
    await donnerCoupDePoing(acteur).catch(() => null);
    // Coups de poing donnés avant la v0.12.6 : impact de coup physique
    const majs = acteur.items.filter(i => (i.flags?.cyberpunk2075?.base === "poing") && !i.system.attaque?.animation?.impact)
      .map(i => ({ _id: i.id, "system.attaque.animation.impact": CONFIG_CP.IMPACT_CONTONDANT }));
    if ( majs.length ) await acteur.updateEmbeddedDocuments("Item", majs).catch(() => null);
  }
});

// Hacks déjà dans le monde avec l'ancienne image (puce de piratage) : image propre à chaque hack
Hooks.once("ready", async () => {
  if ( game.users.activeGM?.id !== game.user.id ) return;
  const ancienne = `${CHEMIN}/assets/notion/implants/puce-de-piratage.webp`;
  const cle = nom => nom.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
  const connus = new Set(["court-circuit", "cyberpsychose", "detonation-involontaire", "dysfonctionnement-d-arme", "dysfonctionnement-d-implant",
    "ping", "protocole-de-violation-rapide", "redemarrage-optique", "suicide", "surchauffe", "pare-feu-reactif", "glitch-visuel", "liberateur-d-ocytocine"]);
  const anciennesCapsules = [`${CHEMIN}/assets/notion/implants/lame-mantis.webp`, "icons/svg/item-bag.svg"];
  const capsules = { neurotox: "capsule-neurotox", electrostatique: "capsule-electrostatique", surchauffante: "capsule-surchauffante" };
  const nouvelle = item => {
    // Capsules de bras : image propre à chaque capsule
    if ( (item.type === "capsule") && anciennesCapsules.includes(item.img) ) {
      const c = Object.entries(capsules).find(([k]) => cle(item.name).includes(k));
      return c ? `${CHEMIN}/assets/notion/implants/${c[1]}.webp` : null;
    }
    if ( (item.type !== "hack") || (item.img !== ancienne) ) return null;
    const c = cle(item.name);
    return connus.has(c) ? `${CHEMIN}/assets/hacks/${c}.webp` : null;
  };
  for ( const item of game.items ) {
    const img = nouvelle(item);
    if ( img ) await item.update({ img }).catch(() => null);
  }
  for ( const acteur of game.actors ) {
    const majs = acteur.items.map(i => ({ _id: i.id, img: nouvelle(i) })).filter(m => m.img);
    if ( majs.length ) await acteur.updateEmbeddedDocuments("Item", majs).catch(() => null);
  }
});

// Marques du hack Ping : redessinées quand la scène, ses drapeaux ou les tokens marqués changent
const redessinerPings = foundry.utils.debounce(() => dessinerPings().catch(() => null), 100);
Hooks.on("canvasReady", redessinerPings);
Hooks.on("updateScene", (scene, changements) => {
  if ( (scene.id === canvas?.scene?.id) && foundry.utils.hasProperty(changements, "flags.cyberpunk2075") ) redessinerPings();
});
for ( const crochet of ["updateToken", "deleteToken"] ) {
  Hooks.on(crochet, doc => {
    if ( (doc.parent?.id === canvas?.scene?.id) && (canvas.scene.flags?.cyberpunk2075?.pings ?? []).some(x => x.cible === doc.id) ) redessinerPings();
  });
}
